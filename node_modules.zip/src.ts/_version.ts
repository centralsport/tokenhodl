export const version = "transactions/5.1.1";
//# sourceMappingURL=_version.js.map