function Smart() {
    return ( <
        section id = "cta" >
        <
        div className = "container"
        data - aos = "zoom-in" >

        <
        div className = "row official_information" >
        <
        div className = "col-lg-4 text-center text-lg-left" >
        <
        h3 > Official Smart Contract < /h3> <
        br / >
        <
        a className = "cta-btn align-middle"
        href = "https://bscscan.com/address/0x0e3eaf83ea93abe756690c62c72284943b96a6bc#code"
        target = "_blank" > Click Here! < /a>

        <
        /div>

        <
        div className = "col-lg-4 text-center text-lg-left burn" >
        <
        h3 > Audit Report < /h3> <
        br / >
        <
        a className = "cta-btn align-middle"
        href = "https://github.com/TechRate/Smart-Contract-Audits/blob/main/HODL.pdf"
        target = "_blank" > Click Here! < /a>

        <
        /div>

        <
        div className = "col-lg-4 text-center text-lg-left" >
        <
        h3 > Liquidity Locks < /h3> <
        br / >
        <
        a className = "cta-btn align-middle"
        href = "https://app.unicrypt.network/amm/pancake-v2/pair/0x2941273449aB4eB6FCdf8f84763F017FaE264091"
        target = "_blank" > Click Here! < /a>

        <
        /div>

        <
        /div>

        <
        /div> <
        /section>
    )
}
export default Smart;