"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IJsonRpcValidator = void 0;
class IJsonRpcValidator {
    constructor(schemas) {
        this.schemas = schemas;
    }
}
exports.IJsonRpcValidator = IJsonRpcValidator;
//# sourceMappingURL=validator.js.map